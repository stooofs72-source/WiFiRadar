package com.wifiradar.app

import android.Manifest
import android.annotation.SuppressLint
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Canvas
import android.graphics.RectF
import android.graphics.Typeface
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.wifi.ScanResult
import android.net.wifi.WifiManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import android.app.Activity
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import java.util.concurrent.Executors
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

class MainActivity : Activity() {
    private lateinit var wifi: WifiManager
    private lateinit var root: LinearLayout
    private lateinit var radar: RadarView
    private lateinit var status: TextView
    private lateinit var networksText: TextView
    private lateinit var connectionText: TextView
    private lateinit var channelText: TextView
    private lateinit var testText: TextView
    private val worker = Executors.newSingleThreadExecutor()
    private val handler = Handler(Looper.getMainLooper())
    private var scanResults: List<ScanResult> = emptyList()
    private var receiverRegistered = false
    private var arabic = false

    private fun tr(en: String, ar: String): String = if (arabic) ar else en

    private val scanReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action != WifiManager.SCAN_RESULTS_AVAILABLE_ACTION) return
            refreshScanResults()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        wifi = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        arabic = getSharedPreferences("settings", MODE_PRIVATE).getBoolean("arabic", false)
        buildUi()
        if (hasLocationPermission()) {
            updateConnectedInfo()
            requestScan()
        } else {
            requestPermissions(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION), 42)
            status.text = tr("Allow location permission so Android can show nearby Wi-Fi networks.", "اسمح بصلاحية الموقع حتى يتمكن Android من عرض شبكات الواي فاي القريبة.")
        }
        handler.post(object : Runnable {
            override fun run() {
                updateConnectedInfo()
                handler.postDelayed(this, 2000)
            }
        })
    }

    private fun buildUi() {
        val scroll = ScrollView(this).apply { setBackgroundColor(Color.rgb(5, 13, 23)) }
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = if (arabic) View.LAYOUT_DIRECTION_RTL else View.LAYOUT_DIRECTION_LTR
            textDirection = if (arabic) View.TEXT_DIRECTION_RTL else View.TEXT_DIRECTION_LTR
            setPadding(dp(16), dp(16), dp(16), dp(24))
        }
        scroll.addView(root)
        setContentView(scroll)

        val title = TextView(this).apply {
            text = "VYRONIX  /  WiFi RADAR"
            textSize = 23f
            setTextColor(Color.rgb(57, 245, 197))
            typeface = Typeface.create("sans-serif-black", Typeface.BOLD)
        }
        root.addView(title)
        root.addView(button(tr("العربية / English", "English / العربية")) {\n            arabic = !arabic\n            getSharedPreferences("settings", MODE_PRIVATE).edit().putBoolean("arabic", arabic).apply()\n            buildUi()\n            updateConnectedInfo()\n            refreshScanResults()\n        }, matchWrap())\n        val subtitle = TextView(this).apply {
            text = tr("NETWORK SCANNER  •  SIGNAL  •  CHANNELS", "البحث عن الشبكات • الإشارة • القنوات")
            textSize = 11f
            setTextColor(Color.rgb(142, 164, 183))
            setPadding(0, dp(4), 0, dp(12))
        }
        root.addView(subtitle)

        radar = RadarView(this)
        root.addView(radar, LinearLayout.LayoutParams(-1, dp(250)))

        status = label("جاهز للمسح. شعل Wi‑Fi وLocation إذا طلبهم Android.")
        root.addView(status)

        val scanButton = button(tr("Scan networks again", "إعادة البحث عن الشبكات")) { requestScan() }
        root.addView(scanButton, matchWrap())

        connectionText = label(tr("Connected network: loading…", "الشبكة المتصل بها: جارٍ تحميل المعلومات…"))
        root.addView(sectionTitle(tr("LIVE SIGNAL", "الإشارة المباشرة")))
        root.addView(connectionText)

        root.addView(sectionTitle(tr("Nearby networks — strongest first", "الشبكات القريبة — من الأقوى إلى الأضعف")))
        networksText = label(tr("No results yet. Tap Scan networks.", "لا توجد نتائج بعد. اضغط على زر البحث."))
        root.addView(networksText)

        root.addView(sectionTitle(tr("Channel analysis", "تحليل القنوات")))
        channelText = label(tr("Channel information appears after scanning.", "ستظهر معلومات القنوات بعد البحث."))
        root.addView(channelText)

        root.addView(sectionTitle(tr("Internet speed & Ping", "سرعة الإنترنت وزمن الاستجابة")))
        testText = label(tr("This test uses real internet data.", "يستخدم الاختبار اتصال الإنترنت وقد يستهلك بعض البيانات."))
        root.addView(testText)
        root.addView(button(tr("Test latency & speed (~1 MB download)", "اختبار زمن الاستجابة والسرعة (تحميل نحو 1 ميغابايت)")) { runSpeedTest() }, matchWrap())

        root.addView(TextView(this).apply {
            text = tr("Note: radar positions are illustrative, not real router locations. Android limits scan frequency, so results may be cached.", "ملاحظة: مواقع النقاط على الرادار توضيحية وليست مواقع حقيقية للراوترات. يحدّ Android من تكرار البحث، وقد تكون النتائج مخزنة مؤقتاً.")
            textSize = 11f
            setTextColor(Color.rgb(142, 164, 183))
            setPadding(0, dp(18), 0, 0)
        })
    }

    private fun sectionTitle(text: String) = TextView(this).apply {
        this.text = text
        textSize = 15f
        typeface = Typeface.DEFAULT_BOLD
        setTextColor(Color.rgb(57, 245, 197))
        setPadding(0, dp(18), 0, dp(6))
    }

    private fun label(text: String) = TextView(this).apply {
        this.text = text
        textSize = 13f
        setTextColor(Color.rgb(224, 236, 246))
        setPadding(dp(10), dp(10), dp(10), dp(10))
        setBackgroundColor(Color.rgb(12, 27, 42))
    }

    private fun button(text: String, action: () -> Unit) = Button(this).apply {
        this.text = text
        setTextColor(Color.rgb(5, 20, 28))
        setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(57, 245, 197)))
        setOnClickListener { action() }
    }

    private fun matchWrap() = LinearLayout.LayoutParams(-1, -2).apply {
        topMargin = dp(8)
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun hasLocationPermission() =
        checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) ==
            PackageManager.PERMISSION_GRANTED

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<out String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 42 && grantResults.isNotEmpty() &&
            grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            updateConnectedInfo()
            requestScan()
        } else {
            status.text = tr("Permission denied. Scanning may not work.", "تم رفض الإذن. قد لا يعمل البحث عن الشبكات.")
        }
    }

    override fun onStart() {
        super.onStart()
        if (!receiverRegistered) {
            val filter = IntentFilter(WifiManager.SCAN_RESULTS_AVAILABLE_ACTION)
            if (Build.VERSION.SDK_INT >= 33) {
                registerReceiver(scanReceiver, filter, Context.RECEIVER_NOT_EXPORTED)
            } else {
                @Suppress("DEPRECATION")
                registerReceiver(scanReceiver, filter)
            }
            receiverRegistered = true
        }
    }

    override fun onStop() {
        if (receiverRegistered) {
            try { unregisterReceiver(scanReceiver) } catch (_: Exception) {}
            receiverRegistered = false
        }
        super.onStop()
    }

    @SuppressLint("MissingPermission")
    private fun requestScan() {
        if (!hasLocationPermission()) {
            requestPermissions(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION), 42)
            return
        }
        if (!wifi.isWifiEnabled) {
            status.text = tr("Wi-Fi is off. Turn it on in Settings and return.", "الواي فاي متوقف. شغّله من الإعدادات ثم ارجع إلى التطبيق.")
            startActivity(Intent(Settings.ACTION_WIFI_SETTINGS))
            return
        }
        if (!isLocationEnabled()) {
            status.text = tr("Turn on Location in Android Settings to scan.", "شغّل الموقع من إعدادات Android حتى يعمل البحث.")
            startActivity(Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS))
            return
        }
        status.text = tr("Requesting a network scan… Android may limit scan frequency.", "جارٍ طلب البحث عن الشبكات… قد يحدّ Android من تكرار البحث.")
        val started = try { wifi.startScan() } catch (_: SecurityException) { false }
        if (!started) {
            refreshScanResults()
            status.text = tr("A new scan was not started; showing the latest available results. Try again later.", "لم يبدأ بحث جديد؛ تُعرض أحدث النتائج المتاحة. حاول مجدداً بعد قليل.")
        }
    }

    private fun isLocationEnabled(): Boolean {
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                getSystemService(android.location.LocationManager::class.java).isLocationEnabled
            } else true
        } catch (_: Exception) { true }
    }

    @SuppressLint("MissingPermission")
    private fun refreshScanResults() {
        if (!hasLocationPermission()) return
        scanResults = try {
            wifi.scanResults
                .filter { it.SSID.isNotBlank() }
                .distinctBy { it.BSSID }
                .sortedByDescending { it.level }
        } catch (_: Exception) { emptyList() }

        radar.setNetworks(scanResults)
        status.text = tr("${scanResults.size} visible networks found. Updated: ${java.text.SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(java.util.Date())}", "تم العثور على ${scanResults.size} شبكة ظاهرة. آخر تحديث: ${java.text.SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(java.util.Date())}")
        networksText.text = if (scanResults.isEmpty()) {
            tr("No network names found. Check permissions and Location, then retry.", "لم تظهر أسماء شبكات. تحقق من الأذونات وتشغيل الموقع ثم حاول مجدداً.")
        } else scanResults.take(30).joinToString("\n\n") { result ->
            val band = when {
                result.frequency in 2400..2500 -> "2.4 GHz"
                result.frequency in 4900..5900 -> "5 GHz"
                result.frequency in 5925..7125 -> "6 GHz"
                else -> "${result.frequency} MHz"
            }
            tr("${signalLabel(result.level)}  ${result.SSID}\n${result.level} dBm  •  $band  •  Channel ${frequencyToChannel(result.frequency)}", "${signalLabel(result.level)}  ${result.SSID}\n${result.level} dBm  •  $band  •  القناة ${frequencyToChannel(result.frequency)}")
        }
        updateChannels()
    }

    private fun updateChannels() {
        if (scanResults.isEmpty()) {
            channelText.text = tr("Not enough results to analyze channels.", "لا توجد نتائج كافية لتحليل القنوات.")
            return
        }
        val counts = scanResults.groupingBy { frequencyToChannel(it.frequency) }.eachCount()
        channelText.text = counts.entries.sortedByDescending { it.value }.joinToString("\n") {
            tr("Channel ${it.key}: ${it.value} visible networks", "القناة ${it.key}: ${it.value} شبكات ظاهرة")
        } + tr("\n\nThis is a simple count, not a complete interference measurement.", "\n\nهذا عدّ تقريبي وليس قياساً كاملاً للتداخل، خصوصاً في نطاقي 5 و6 غيغاهرتز.")
    }

    @SuppressLint("MissingPermission")
    private fun updateConnectedInfo() {
        try {
            val info = wifi.connectionInfo
            val connected = wifi.isWifiEnabled && info != null && info.networkId != -1 &&
                info.ssid != WifiManager.UNKNOWN_SSID
            connectionText.text = if (connected) {
                val ssid = info.ssid.trim('"')
                val rssi = info.rssi
                val freq = info.frequency
                val link = if (Build.VERSION.SDK_INT >= 29) info.rxLinkSpeed else -1
                "SSID: $ssid\nالإشارة: $rssi dBm (${signalLabel(rssi)})\nالتردد: ${freq} MHz\nسرعة الربط المستقبلة: ${if (link >= 0) "$link Mbps" else "غير متوفرة"}"
            } else {
                tr("The phone does not appear to be connected to Wi-Fi. Check Wi-Fi settings.", "يبدو أن الهاتف غير متصل بالواي فاي. تحقق من إعدادات Wi-Fi.")
            }
        } catch (_: Exception) {
            connectionText.text = tr("Android hid some connection details. Check permissions.", "حجب Android بعض معلومات الاتصال. تحقق من الأذونات.")
        }
    }

    private fun runSpeedTest() {
        testText.text = tr("Measuring latency and speed…", "جارٍ قياس زمن الاستجابة والسرعة…")
        worker.execute {
            var pingMs = -1L
            var speedMbps = -1.0
            var error = ""
            try {
                val pingStart = System.nanoTime()
                val pingConn = (URL("https://www.google.com/generate_204").openConnection() as HttpURLConnection)
                pingConn.connectTimeout = 5000
                pingConn.readTimeout = 5000
                pingConn.instanceFollowRedirects = false
                pingConn.requestMethod = "GET"
                pingConn.connect()
                pingConn.responseCode
                pingMs = (System.nanoTime() - pingStart) / 1_000_000
                pingConn.disconnect()

                val bytesWanted = 1_000_000
                val speedUrl = URL("https://speed.cloudflare.com/__down?bytes=$bytesWanted")
                val conn = (speedUrl.openConnection() as HttpURLConnection)
                conn.connectTimeout = 7000
                conn.readTimeout = 10000
                conn.setRequestProperty("Cache-Control", "no-cache")
                val start = System.nanoTime()
                conn.inputStream.use { input ->
                    val buffer = ByteArray(8192)
                    var total = 0L
                    while (true) {
                        val n = input.read(buffer)
                        if (n <= 0) break
                        total += n
                    }
                    val seconds = ((System.nanoTime() - start).coerceAtLeast(1L)) / 1_000_000_000.0
                    if (seconds > 0 && total > 0) speedMbps = total * 8.0 / seconds / 1_000_000.0
                }
                conn.disconnect()
            } catch (e: Exception) {
                error = e.message ?: "تعذر الاتصال بخادم الاختبار"
            }
            val p = pingMs
            val s = speedMbps
            val err = error
            runOnUiThread {
                testText.text = if (p >= 0 && s > 0) {
                    tr("HTTPS response time: $p ms\nApprox. download speed: ${String.format(Locale.US, "%.2f", s)} Mbps\nResults vary with server and signal.", "زمن استجابة HTTPS: $p مللي ثانية\nسرعة التحميل التقريبية: ${String.format(Locale.US, "%.2f", s)} ميغابت/ث\nتختلف النتائج حسب الخادم والإشارة والضغط.")
                } else {
                    tr("Test failed: $err\nCheck your internet and try again.", "فشل الاختبار: $err\nتحقق من الإنترنت ثم حاول مجدداً.")
                }
            }
        }
    }

    private fun signalLabel(dbm: Int): String = when {
        dbm >= -50 -> tr("Excellent", "ممتاز")
        dbm >= -60 -> tr("Strong", "قوي")
        dbm >= -67 -> tr("Good", "جيد")
        dbm >= -75 -> tr("Fair", "متوسط")
        else -> tr("Weak", "ضعيف")
    }

    private fun frequencyToChannel(freq: Int): String = when {
        freq == 2484 -> "14"
        freq in 2412..2472 -> ((freq - 2407) / 5).toString()
        freq in 5000..5895 -> ((freq - 5000) / 5).toString()
        freq in 5955..7115 -> ((freq - 5950) / 5).toString()
        else -> "?"
    }

    override fun onDestroy() {
        worker.shutdownNow()
        handler.removeCallbacksAndMessages(null)
        super.onDestroy()
    }
}

private class RadarView(context: Context) : View(context) {
    private val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(30, 116, 116)
        style = Paint.Style.STROKE
        strokeWidth = 1.5f
    }
    private val sweepPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(70, 57, 245, 197)
        style = Paint.Style.FILL
    }
    private val dotPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(142, 220, 211)
        textSize = 10f * resources.displayMetrics.density
    }
    private var networks: List<ScanResult> = emptyList()
    private var angle = 0f
    private val handler = Handler(Looper.getMainLooper())
    private val tick = object : Runnable {
        override fun run() {
            angle = (angle + 3.5f) % 360f
            invalidate()
            handler.postDelayed(this, 50)
        }
    }

    init { handler.post(tick) }

    fun setNetworks(items: List<ScanResult>) {
        networks = items.take(24)
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        canvas.drawColor(Color.rgb(5, 13, 23))
        val cx = width / 2f
        val cy = height / 2f
        val radius = min(width * 0.43f, height * 0.43f)
        for (i in 1..4) canvas.drawCircle(cx, cy, radius * i / 4f, linePaint)
        canvas.drawLine(cx - radius, cy, cx + radius, cy, linePaint)
        canvas.drawLine(cx, cy - radius, cx, cy + radius, linePaint)

        val sweep = RectF(cx - radius, cy - radius, cx + radius, cy + radius)
        canvas.save()
        canvas.rotate(angle, cx, cy)
        canvas.drawArc(sweep, -32f, 32f, true, sweepPaint)
        canvas.restore()

        networks.forEachIndexed { index, result ->
            val strength = ((result.level + 100).coerceIn(0, 60) / 60f)
            val r = radius * (0.25f + (1f - strength) * 0.68f)
            val theta = Math.toRadians(((index * 137.5) % 360.0))
            val x = cx + cos(theta).toFloat() * r
            val y = cy + sin(theta).toFloat() * r
            dotPaint.color = when {
                result.level >= -55 -> Color.rgb(57, 245, 197)
                result.level >= -70 -> Color.rgb(255, 202, 74)
                else -> Color.rgb(255, 105, 105)
            }
            canvas.drawCircle(x, y, 3.5f * resources.displayMetrics.density, dotPaint)
        }
        canvas.drawText(if (context.getSharedPreferences("settings", Context.MODE_PRIVATE).getBoolean("arabic", false)) "رادار مباشر" else "LIVE RADAR", dp(10f), dp(18f), textPaint)
        canvas.drawText(if (context.getSharedPreferences("settings", Context.MODE_PRIVATE).getBoolean("arabic", false)) "${networks.size} شبكة" else "${networks.size} networks", dp(10f), height - dp(8f), textPaint)
    }

    private fun dp(v: Float) = v * resources.displayMetrics.density

    override fun onDetachedFromWindow() {
        handler.removeCallbacks(tick)
        super.onDetachedFromWindow()
    }
}
