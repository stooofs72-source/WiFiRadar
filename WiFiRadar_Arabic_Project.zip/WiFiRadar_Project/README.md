# WiFiRadar

Android Wi-Fi analyzer prototype written in Kotlin.

## Features
- Nearby Wi-Fi scan results sorted by RSSI.
- Animated radar-style visualization (illustrative positions, not physical locations).
- Connected Wi-Fi RSSI and link details.
- Basic channel counts from visible scan results.
- Optional HTTPS latency and approximate download-speed test (~1 MB).

## Build an APK
1. Install Android Studio on a computer.
2. Extract this project ZIP.
3. Open the `WiFiRadar_Project` folder in Android Studio.
4. Allow Gradle sync/downloads to finish.
5. Choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
6. Find the APK at `app/build/outputs/apk/debug/app-debug.apk`.
7. Copy it to the Android phone and install it. If prompted, allow installation from that file manager.

## Android permissions and limitations
- The app requests `ACCESS_FINE_LOCATION` because Android requires it for Wi-Fi scan results on modern Android versions.
- Enable Wi-Fi and Location on the phone.
- Android throttles scan requests; the app cannot force continuous hardware scanning.
- RSSI is the phone's measured signal, not a way to boost radio power.
- Channel counts are a rough view of visible networks, not a complete RF interference measurement.
- Speed test requires internet and downloads about 1 MB from Cloudflare; the result is approximate and may use mobile data if Wi-Fi drops.
- The app does not collect or upload nearby network data itself.

## Language support
- In-app English / Arabic toggle.
- Arabic switches the layout to right-to-left (RTL).
- The selected language is saved on the device.
